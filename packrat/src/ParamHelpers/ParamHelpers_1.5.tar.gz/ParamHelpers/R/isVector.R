isVector = function(x) {
  grepl("vector", x$type)
}
