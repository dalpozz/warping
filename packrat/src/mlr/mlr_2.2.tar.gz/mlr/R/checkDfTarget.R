checkDfTarget = function(df, target) {
  assertSubset(target, choices = colnames(target))
}
