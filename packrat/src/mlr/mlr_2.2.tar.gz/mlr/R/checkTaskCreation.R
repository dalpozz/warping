checkTaskCreation = function(task, target, ...) {
  UseMethod("checkTaskCreation")
}
