fixupData = function(task, target, choice, ...) {
  UseMethod("fixupData")
}
