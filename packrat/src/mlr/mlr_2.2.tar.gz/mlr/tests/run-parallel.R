library(testthat)
# FIXME: I am not sure if enabling this leads to travis 'hanging'. we currently must test it locally
# if (identical(Sys.getenv("TRAVIS"), "true")) {
  # test_check("mlr", "_parallel_")
# }

