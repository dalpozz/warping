test.tostring = function() {
	print(binaryclass.task)
	print(regr.task)
	wl = makeLearner("classif.lda")
	print(wl)
}
