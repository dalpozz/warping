context("show options")

test_that("show options", {
  capture.output(
    parallelShowOptions()
  )
})